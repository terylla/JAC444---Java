import java.text.DecimalFormat;

public class Student {

    private String firstName;
    private String lastName;
    private double grade;
    private String department;

    // CONSTRUCTOR //
    Student(String first, String last, double grade, String dep) {
       // if (first != null && last != null && grade != 0 && dep != null) {
            this.firstName = first;
            this.lastName = last;
            this.grade = grade;
            this.department = dep;
       // }
    }

    /////////////////////////*** GETTER ***//////////////////////////

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;

    }
    public double getGrade() {
        return grade;
    }

    public String getDepartment() {
        return department;
    }

    public String getName(){
         return lastName + " " + firstName ;
    }

    /////////////////////////*** SETTER ***//////////////////////////

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    ///////// OTHER METHODS ////////
    public boolean equals(Student stu){
        if (stu == this) {
            return true;
        } else return false;
    }


    public String toString(){
        DecimalFormat df = new DecimalFormat("00.00");
        return getFirstName() + "\t" +
                getLastName() +"\t" +
                df.format(getGrade()) +"\t" +
                getDepartment();

    }



}
